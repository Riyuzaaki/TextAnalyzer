
from django.http import HttpResponse
import string
from django.shortcuts import render
def index(request):
    return render(request, 'index.html')

def removepunc(a):
    punctuations = string.punctuation
    analyzed = ""
    for char in a:
        if char not in punctuations:
            analyzed += char
    return analyzed

def uppercase(a):
    return a.upper()

def newline(a):
    analyzed = ""
    for char in a:
        if char != '\n' and char!='\r':
            analyzed += char
    return analyzed

def extraspace(a):
    analyzed = ""
    for i, char in enumerate(a):
        if not( a[i]==" " and a[i+1]==" "):
            analyzed += char
    return analyzed
def countchar(a):
    return len(a);

def analyze(request):
    a = request.POST.get('text', 'default')
    removepunc1 = request.POST.get('removepunc', 'off')
    if removepunc1 == 'on':
        a = removepunc(a)

    uppercase1 = request.POST.get('uppercase','off')
    if uppercase1 == 'on':
        a = uppercase(a)

    newline1 = request.POST.get('newline','off')
    if newline1=='on':
        a = newline(a)

    extraspace1 = request.POST.get('extraspace', 'off')
    if extraspace1=='on':
        a = extraspace(a)

    countchar1 = request.POST.get('countchar', 'off')
    b=0
    if countchar1 =='on':
        b = countchar(a)

    params = {'purpose': 'Remove Punctuations','analyzed_text': a,'count':b}
    return render(request, 'analyze.html', params)

# def capfirst(request):
#     return HttpResponse("capfirst")

# def newlineremove(request):
#     return HttpResponse("newlineremove")
#
# def spaceremove(request):
#     return HttpResponse("spaceremove")
#
# def charcount(request):
#     return HttpResponse("charcount")